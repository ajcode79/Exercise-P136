﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tour_project
{
    public partial class Form1 : Form
    {
        int arash;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            label2.Visible = false;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            label3.Visible = false;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            label5.Visible = false;
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            label6.Visible = false;
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            label7.Visible = false;
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            label8.Visible = false;
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            label9.Visible = false;
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            label10.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            arash = rnd.Next(1, 6);
            string s = arash.ToString() + ".png";
            pictureBox1.ImageLocation = s;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (arash)
            {
                case 1:
                    MessageBox.Show("پاسخ صحیح : مسجد نصیر الملک در شیراز", "پاسخ صحیح", MessageBoxButtons.OKCancel);
                    break;
                case 2:
                    MessageBox.Show("پاسخ صحیح : مسجد شیخ لطف ‌الله در اصفحان", "پاسخ صحیح", MessageBoxButtons.OKCancel);
                    break;
                case 3:
                    MessageBox.Show("پاسخ صحیح : ارگ بم در کرمان", "پاسخ صحیح", MessageBoxButtons.OKCancel);
                    break;
                case 4:
                    MessageBox.Show("پاسخ صحیح : کاخ گلستان در تهران", "پاسخ صحیح", MessageBoxButtons.OKCancel);
                    break;
                case 5:
                    MessageBox.Show("پاسخ صحیح : تخت جمشید در شیراز", "پاسخ صحیح", MessageBoxButtons.OKCancel);
                    break;
                case 6:
                    MessageBox.Show("پاسخ صحیح : حمام سلطان امیر احمد در کاشان", "پاسخ صحیح", MessageBoxButtons.OKCancel);
                    break;
                default:
                    MessageBox.Show(" بیشتر تلاش کن", "پاسخ صحیح", MessageBoxButtons.OKCancel);
                    break;
            }
        }
    }
}
